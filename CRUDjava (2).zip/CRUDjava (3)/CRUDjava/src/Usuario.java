import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/**
 * Classe que representa um Usuário no sistema.
 */
public class Usuario {
    // Atributos
    private int id; // ID único do usuário
    private String nome; // Nome completo do usuário
    private String cpf; // CPF do usuário
    private String email; // Endereço de email do usuário
    private Date dataNascimento; // Data de nascimento do usuário (tipo Date)
    private String sexo; // Sexo do usuário (M/F)
    private String tipoDiabetes; // Tipo de diabetes do usuário
    private Date dataDiagnostico; // Data do diagnóstico de diabetes (tipo Date)
    private int nivelAcucarSangue; // Nível de açúcar no sangue do usuário
    private float peso; // Peso do usuário em kg
    private float altura; // Altura do usuário em metros
    private String pressaoArterial; // Pressão arterial do usuário
    private String historicoMedico; // Histórico médico do usuário
    private String medicamentos; // Medicamentos que o usuário está tomando
    private String alergias; // Alergias do usuário
    private String senha; // Senha do usuário para autenticação

    // Construtor
    /**
     * Construtor padrão da classe Usuario. Inicializa os atributos com valores vazios ou zero.
     */
    public Usuario() {
        this.id = 0;
        this.nome = "";
        this.cpf = "";
        this.email = "";
        this.senha = "";
        this.sexo = "";
        this.tipoDiabetes = "";
        this.nivelAcucarSangue = 0;
        this.peso = 0.0f;
        this.altura = 0.0f;
        this.pressaoArterial = "";
        this.historicoMedico = "";
        this.medicamentos = "";
        this.alergias = "";
    }

    // Getters e Setters
    /**
     * Retorna o ID do usuário.
     * @return O ID do usuário.
     */
    public int getId() {
        return id;
    }

    /**
     * Define o ID do usuário.
     * @param id O novo ID do usuário.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Retorna o nome do usuário.
     * @return O nome do usuário.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o nome do usuário.
     * @param nome O novo nome do usuário.
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Retorna o CPF do usuário.
     * @return O CPF do usuário.
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * Define o CPF do usuário.
     * @param cpf O novo CPF do usuário.
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * Retorna o email do usuário.
     * @return O email do usuário.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Define o email do usuário.
     * @param email O novo email do usuário.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Retorna a senha do usuário.
     * @return A senha do usuário.
     */
    public String getSenha() {
        return senha;
    }

    /**
     * Define a senha do usuário.
     * @param senha A nova senha do usuário.
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * Retorna a data de nascimento do usuário como um objeto Date.
     * @return A data de nascimento do usuário.
     */
    public Date getDataNascimento() {
        return dataNascimento;
    }

    /**
     * Define a data de nascimento do usuário.
     * @param dataNascimento A nova data de nascimento do usuário.
     */
    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    /**
     * Retorna a data de nascimento do usuário formatada como uma String no formato "dd/MM/yyyy".
     * @return A data de nascimento formatada ou uma string vazia se a data for nula.
     */
    public String getDataNascimentoFormatada() {
        if (dataNascimento != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            return dateFormat.format(dataNascimento);
        } else {
            return "";
        }
    }

    /**
     * Define a data de nascimento do usuário a partir de uma String no formato "dd/MM/yyyy".
     * @param dataNascimentoStr A data de nascimento como String.
     */
    public void setDataNascimentoFromString(String dataNascimentoStr) {
        if (dataNascimentoStr != null && !dataNascimentoStr.isEmpty()) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            try {
                this.dataNascimento = dateFormat.parse(dataNascimentoStr);
            } catch (ParseException e) {
                System.err.println("Formato de data inválido. A data deve estar no formato DD/MM/AAAA.");
            }
        }
    }

    /**
     * Retorna o sexo do usuário.
     * @return O sexo do usuário.
     */
    public String getSexo() {
        return sexo;
    }

    /**
     * Define o sexo do usuário.
     * @param sexo O novo sexo do usuário.
     */
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    /**
     * Retorna o tipo de diabetes do usuário.
     * @return O tipo de diabetes do usuário.
     */
    public String getTipoDiabetes() {
        return tipoDiabetes;
    }

    /**
     * Define o tipo de diabetes do usuário.
     * @param tipoDiabetes O novo tipo de diabetes do usuário.
     */
    public void setTipoDiabetes(String tipoDiabetes) {
        this.tipoDiabetes = tipoDiabetes;
    }

    /**
     * Retorna a data do diagnóstico de diabetes do usuário como um objeto Date.
     * @return A data do diagnóstico de diabetes do usuário.
     */
    public Date getDataDiagnostico() {
        return dataDiagnostico;
    }

    /**
     * Define a data do diagnóstico de diabetes do usuário.
     * @param dataDiagnostico A nova data do diagnóstico de diabetes do usuário.
     */
    public void setDataDiagnostico(Date dataDiagnostico) {
        this.dataDiagnostico = dataDiagnostico;
    }

    /**
     * Retorna a data do diagnóstico de diabetes do usuário formatada como uma String no formato "dd/MM/yyyy".
     * @return A data do diagnóstico formatada ou uma string vazia se a data for nula.
     */
    public String getDataDiagnosticoFormatada() {
        if (dataDiagnostico != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            return dateFormat.format(dataDiagnostico);
        } else {
            return "";
        }
    }

    /**
     * Define a data do diagnóstico de diabetes do usuário a partir de uma String no formato "dd/MM/yyyy".
     * @param dataDiagnosticoStr A data do diagnóstico como String.
     */
    public void setDataDiagnosticoFromString(String dataDiagnosticoStr) {
        if (dataDiagnosticoStr != null && !dataDiagnosticoStr.isEmpty()) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            try {
                this.dataDiagnostico = dateFormat.parse(dataDiagnosticoStr);
            } catch (ParseException e) {
                System.err.println("Formato de data inválido. A data deve estar no formato DD/MM/AAAA.");
            }
        }
    }

    /**
     * Retorna o nível de açúcar no sangue do usuário.
     * @return O nível de açúcar no sangue do usuário.
     */
    public int getNivelAcucarSangue() {
        return nivelAcucarSangue;
    }

    /**
     * Define o nível de açúcar no sangue do usuário.
     * @param nivelAcucarSangue O novo nível de açúcar no sangue do usuário.
     */
    public void setNivelAcucarSangue(int nivelAcucarSangue) {
        this.nivelAcucarSangue = nivelAcucarSangue;
    }

    /**
     * Retorna o peso do usuário.
     * @return O peso do usuário.
     */
    public float getPeso() {
        return peso;
    }

    /**
     * Define o peso do usuário.
     * @param peso O novo peso do usuário.
     */
    public void setPeso(float peso) {
        this.peso = peso;
    }

    /**
     * Retorna a altura do usuário.
     * @return A altura do usuário.
     */
    public float getAltura() {
        return altura;
    }

    /**
     * Define a altura do usuário.
     * @param altura A nova altura do usuário.
     */
    public void setAltura(float altura) {
        this.altura = altura;
    }

    /**
     * Retorna as alergias do usuário.
     * @return As alergias do usuário.
     */
    public String getAlergias() {
        return alergias;
    }

    /**
     * Define as alergias do usuário.
     * @param alergias As novas alergias do usuário.
     */
    public void setAlergias(String alergias) {
        this.alergias = alergias;
    }

    /**
     * Retorna a pressão arterial do usuário.
     * @return A pressão arterial do usuário.
     */
    public String getPressaoArterial() {
        return pressaoArterial;
    }

    /**
     * Define a pressão arterial do usuário.
     * @param pressaoArterial A nova pressão arterial do usuário.
     */
    public void setPressaoArterial(String pressaoArterial) {
        this.pressaoArterial = pressaoArterial;
    }

    /**
     * Retorna os medicamentos que o usuário está tomando.
     * @return Os medicamentos que o usuário está tomando.
     */
    public String getMedicamentos() {
        return medicamentos;
    }

    /**
     * Define os medicamentos que o usuário está tomando.
     * @param medicamentos Os novos medicamentos que o usuário está tomando.
     */
    public void setMedicamentos(String medicamentos) {
        this.medicamentos = medicamentos;
    }

    /**
     * Retorna o histórico médico do usuário.
     * @return O histórico médico do usuário.
     */
    public String getHistoricoMedico() {
        return historicoMedico;
    }

    /**
     * Define o histórico médico do usuário.
     * @param historicoMedico O novo histórico médico do usuário.
     */
    public void setHistoricoMedico(String historicoMedico) {
        this.historicoMedico = historicoMedico;
    }

    /**
     * Sobrescreve o método equals para comparar usuários pelo ID.
     * @param o O objeto a ser comparado.
     * @return True se os objetos são iguais (têm o mesmo ID), False caso contrário.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return id == usuario.id;
    }

    /**
     * Sobrescreve o método hashCode para gerar um código hash baseado na senha do usuário.
     * @return O código hash do usuário.
     */
    @Override
    public int hashCode() {
        return Objects.hash(senha);
    }

    /**
     * Sobrescreve o método toString para retornar uma representação em String do usuário.
     * @return A representação em String do usuário.
     */
    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", cpf='" + cpf + '\'' +
                ", email='" + email + '\'' +
                ", senha='" + senha + '\'' +
                ", dataNascimento='" + dataNascimento + '\'' +
                ", sexo='" + sexo + '\'' +
                ", tipoDiabetes=" + tipoDiabetes +
                ", dataDiagnostico='" + dataDiagnostico + '\'' +
                ", nivelAcucarSangue=" + nivelAcucarSangue +
                ", peso=" + peso +
                ", altura=" + altura +
                ", pressaoArterial='" + pressaoArterial + '\'' +
                ", historicoMedico='" + historicoMedico + '\'' +
                ", medicamentos='" + medicamentos + '\'' +
                ", alergias='" + alergias + '\'' +
                '}';
    }
}