import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class UsuarioGUI extends JFrame {

    // Define as cores a serem usadas na interface gráfica
    private Color primaryColor = new Color(0, 123, 255); // Azul
    private Color secondaryColor = new Color(248, 249, 250); // Cinza
    private Color darkTextColor = new Color(34, 34, 34); // Cinza

    // Declara os componentes da interface gráfica para entrada de dados do usuário
    private JTextField txtNome;
    private JTextField txtCpf;
    private JTextField txtEmail;
    private JFormattedTextField txtDataNascimento; // Campo formatado para data de nascimento
    private JComboBox<String> cbSexo; // Caixa de seleção para o sexo
    private JComboBox<String> cbTipoDiabetes; // Caixa de seleção para o tipo de diabetes
    private JFormattedTextField txtDataDiagnostico; // Campo formatado para data de diagnóstico
    private JTextField txtNivelAcucarSangue;
    private JTextField txtPeso;
    private JTextField txtAltura;
    private JTextField txtPressaoArterial;
    private JTextArea txtHistoricoMedico; // Área de texto para histórico médico
    private JTextArea txtMedicamentos; // Área de texto para medicamentos
    private JTextArea txtAlergias; // Área de texto para alergias
    private JPasswordField txtSenha; // Campo de senha
    private JButton btnCriar; // Botão para criar usuário
    private JButton btnLimpar; // Botão para limpar os campos de entrada

    // Variáveis para conexão com o banco de dados e manipulação da tabela de usuários
    private Connection conexao;
    private JButton btnListarUsuarios; // Botão para listar usuários
    private JTable tabelaUsuarios; // Tabela para exibir os usuários
    private DefaultTableModel modeloTabela; // Modelo da tabela de usuários
    private JPanel painelTabela; // Painel para conter a tabela de usuários
    private JTextField txtIdExcluir; // Campo de texto para o ID do usuário a ser excluído
    private JButton btnExcluir; // Botão para excluir o usuário
    private JTextField txtIdBuscar; // Campo para digitar o ID a ser buscado
    private JButton btnBuscar; // Botão para iniciar a busca

    public UsuarioGUI() {
        super("Criar Usuário"); // Define o título da janela

        // Tenta estabelecer a conexão com o banco de dados
        try {
            this.conexao = ConexaoBanco.obterConexao();
        } catch (SQLException e) {
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
        }

        // Define o comportamento de fechamento da janela, tamanho e posição
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 900);
        setLocationRelativeTo(null);

        // Cria o painel principal com layout GridBagLayout
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBackground(secondaryColor);
        GridBagConstraints gbc = new GridBagConstraints(); // Define as restrições de layout
        gbc.insets = new Insets(5, 10, 5, 10); // Define as margens entre os componentes

        // Cria o título da janela
        JLabel lblTitulo = new JLabel("Criar Usuário");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitulo.setForeground(primaryColor);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        painel.add(lblTitulo, gbc);

        // Adiciona os campos de entrada de dados ao painel
        adicionarCampo(painel, "Nome:", txtNome = new JTextField(), 1);
        adicionarCampo(painel, "CPF:", txtCpf = new JTextField(), 2);
        adicionarCampo(painel, "Email:", txtEmail = new JTextField(), 3);
        adicionarCampo(painel, "Data de Nascimento (DD/MM/AAAA):",
                txtDataNascimento = new JFormattedTextField(new SimpleDateFormat("dd/MM/yyyy")), 4);
        adicionarCampo(painel, "Sexo:", cbSexo = new JComboBox<>(new String[]{"M", "F"}), 5);
        adicionarCampo(painel, "Tipo de Diabetes:",
                cbTipoDiabetes = new JComboBox<>(new String[]{"Tipo 1", "Tipo 2", "Gestacional", "Outros"}), 6);
        adicionarCampo(painel, "Data de Diagnóstico (DD/MM/AAAA):",
                txtDataDiagnostico = new JFormattedTextField(new SimpleDateFormat("dd/MM/yyyy")), 7);
        adicionarCampo(painel, "Nível de Açúcar no Sangue (mg/dL):",
                txtNivelAcucarSangue = new JTextField(), 8);
        adicionarCampo(painel, "Peso (kg):", txtPeso = new JTextField(), 9);
        adicionarCampo(painel, "Altura (m):", txtAltura = new JTextField(), 10);
        adicionarCampo(painel, "Pressão Arterial (mmHg):", txtPressaoArterial = new JTextField(), 11);
        adicionarCampoTextArea(painel, "Histórico Médico:", txtHistoricoMedico = new JTextArea(3, 20), 12);
        adicionarCampoTextArea(painel, "Medicamentos:", txtMedicamentos = new JTextArea(3, 20), 13);
        adicionarCampoTextArea(painel, "Alergias:", txtAlergias = new JTextArea(3, 20), 14);
        adicionarCampo(painel, "Senha:", txtSenha = new JPasswordField(), 15);

        // Cria o botão "Criar Usuário" e adiciona um ActionListener para lidar com o evento de clique
        btnCriar = new JButton("Criar Usuário");
        btnCriar.setBackground(primaryColor);
        btnCriar.setForeground(Color.WHITE);
        btnCriar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                criarUsuario(); // Chama o método criarUsuario() quando o botão é clicado
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 16;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(btnCriar, gbc);

        adicionarCampo(painel, "ID para Buscar:", txtIdBuscar = new JTextField(), 21);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBackground(primaryColor);
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarUsuarioPorId();
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 22;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(btnBuscar, gbc);

        // ... (código de inicialização restante) ...

        // Cria o botão "Limpar Dados" e adiciona um ActionListener para lidar com o evento de clique
        btnLimpar = new JButton("Limpar Dados");
        btnLimpar.setBackground(Color.LIGHT_GRAY);
        btnLimpar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limparCampos(); // Chama o método limparCampos() quando o botão é clicado
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 16;
        painel.add(btnLimpar, gbc);

        adicionarCampo(painel, "ID do Usuário:", txtIdExcluir = new JTextField(), 19);
        btnExcluir = new JButton("Excluir Usuário");
        btnExcluir.setBackground(Color.RED);
        btnExcluir.setForeground(Color.WHITE);
        btnExcluir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                excluirUsuario(); // Chama o método excluirUsuario() quando o botão é clicado
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 20;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(btnExcluir, gbc);

        // ... (restante do código de inicialização da janela)


        // Cria o botão "Listar Usuários" e adiciona um ActionListener para lidar com o evento de clique
        btnListarUsuarios = new JButton("Listar Usuários");
        btnListarUsuarios.setBackground(primaryColor);
        btnListarUsuarios.setForeground(Color.WHITE);
        btnListarUsuarios.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listarUsuarios(); // Chama o método listarUsuarios() quando o botão é clicado
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 17;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(btnListarUsuarios, gbc);

        // Cria o painel para a tabela de usuários, inicialmente invisível
        painelTabela = new JPanel(new BorderLayout());
        painelTabela.setVisible(false);
        gbc.gridx = 0;
        gbc.gridy = 18;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        painel.add(painelTabela, gbc);

        // Cria a tabela de usuários e a adiciona a um JScrollPane para permitir rolagem
        modeloTabela = new DefaultTableModel();
        tabelaUsuarios = new JTable(modeloTabela);
        JScrollPane scrollPane = new JScrollPane(tabelaUsuarios);
        painelTabela.add(scrollPane, BorderLayout.CENTER);

        // Adiciona o painel principal à janela
        add(painel);

        // Define a janela como visível
        setVisible(true);
    }

    // Método auxiliar para adicionar campos de entrada de texto ao painel
    private void adicionarCampo(JPanel painel, String labelText, JComponent componente, int gridy) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.gridx = 0;
        gbc.gridy = gridy;
        gbc.anchor = GridBagConstraints.WEST;
        painel.add(new JLabel(labelText), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(componente, gbc);
    }

    // Método auxiliar para adicionar áreas de texto ao painel
    private void adicionarCampoTextArea(JPanel painel, String labelText, JTextArea componente, int gridy) {
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.gridx = 0;
        gbc.gridy = gridy;
        gbc.anchor = GridBagConstraints.WEST;
        painel.add(new JLabel(labelText), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        painel.add(new JScrollPane(componente), gbc); // Adiciona a área de texto a um JScrollPane
    }

    // Método para criar um novo usuário no banco de dados
    private void criarUsuario() {
        UsuarioDAO dao = new UsuarioDAO(); // Cria uma instância da classe UsuarioDAO para interagir com o banco de dados
        try {
            // Cria uma nova instância da classe Usuario e preenche seus atributos com os dados dos campos de entrada
            Usuario usuario = new Usuario();
            usuario.setNome(txtNome.getText());
            usuario.setCpf(txtCpf.getText());
            usuario.setEmail(txtEmail.getText());

            // Usa o método setDataNascimentoFromString para converter a String da data de nascimento para Date
            usuario.setDataNascimentoFromString(txtDataNascimento.getText());
            usuario.setSexo(cbSexo.getSelectedItem().toString());

            usuario.setTipoDiabetes(cbTipoDiabetes.getSelectedItem().toString());

            // Usa o método setDataDiagnosticoFromString para converter a String da data de diagnóstico para Date
            usuario.setDataDiagnosticoFromString(txtDataDiagnostico.getText());

            usuario.setNivelAcucarSangue(Integer.parseInt(txtNivelAcucarSangue.getText()));
            usuario.setPeso(Float.parseFloat(txtPeso.getText()));
            usuario.setAltura(Float.parseFloat(txtAltura.getText()));
            usuario.setPressaoArterial(txtPressaoArterial.getText());
            usuario.setHistoricoMedico(txtHistoricoMedico.getText());
            usuario.setMedicamentos(txtMedicamentos.getText());
            usuario.setAlergias(txtAlergias.getText());
            usuario.setSenha(new String(txtSenha.getPassword()));

            // Salva o usuário no banco de dados usando o método salvar() da classe UsuarioDAO
            dao.salvar(usuario);
            dao.fecharConexao(); // Fecha a conexão com o banco de dados

            // Exibe uma mensagem de sucesso
            JOptionPane.showMessageDialog(this, "Usuário criado com sucesso!");
            limparCampos(); // Limpa os campos de entrada após criar o usuário
        } catch (SQLException ex) {
            // Exibe uma mensagem de erro se houver algum problema ao interagir com o banco de dados
            JOptionPane.showMessageDialog(this, "Erro ao criar usuário: " + ex.getMessage());
        } catch (NumberFormatException ex) {
            // Exibe uma mensagem de erro se houver algum problema ao converter os dados numéricos
            JOptionPane.showMessageDialog(this, "Erro: Insira dados numéricos válidos para Nível de Açúcar no Sangue, Peso e Altura.");
        }
        // Não precisa mais do catch (ParseException ex) aqui, pois ele é tratado no setDataNascimentoFromString
    }
    private void buscarUsuarioPorId() {
        try {
            int id = Integer.parseInt(txtIdBuscar.getText());
            UsuarioDAO dao = new UsuarioDAO();
            Usuario usuario = dao.buscarId(id); // Busca o usuário
            dao.fecharConexao();

            // Limpa a tabela
            modeloTabela.setRowCount(0);

            // Define as colunas da tabela
            modeloTabela.setColumnIdentifiers(new String[]{
                    "ID", "Nome", "CPF", "Email", "Data de Nascimento", "Sexo",
                    "Tipo de Diabetes", "Data de Diagnóstico", "Nível de Açúcar",
                    "Peso", "Altura", "Pressão Arterial", "Histórico Médico",
                    "Medicamentos", "Alergias"
            });

            // Se o usuário foi encontrado, adiciona-o à tabela
            if (usuario != null) {
                modeloTabela.addRow(new Object[]{
                        usuario.getId(), usuario.getNome(), usuario.getCpf(), usuario.getEmail(),
                        usuario.getDataNascimento(), usuario.getSexo(), usuario.getTipoDiabetes(),
                        usuario.getDataDiagnostico(), usuario.getNivelAcucarSangue(),
                        usuario.getPeso(), usuario.getAltura(), usuario.getPressaoArterial(),
                        usuario.getHistoricoMedico(), usuario.getMedicamentos(), usuario.getAlergias()
                });
            } else {
                // Se o usuário não foi encontrado, exibe uma mensagem
                JOptionPane.showMessageDialog(this, "Usuário não encontrado.");
            }

            // Torna a tabela visível
            painelTabela.setVisible(true);

        } catch (NumberFormatException ex) {
            // Exibe uma mensagem de erro se o ID não for um número inteiro válido
            JOptionPane.showMessageDialog(this, "Erro: Insira um ID válido.");
        } catch (SQLException ex) {
            // Exibe uma mensagem de erro se houver algum problema ao interagir com o banco de dados
            JOptionPane.showMessageDialog(this, "Erro ao buscar usuário: " + ex.getMessage());
        }
    }
    // Método para limpar os campos de entrada de dados
    private void limparCampos() {
        txtNome.setText("");
        txtCpf.setText("");
        txtEmail.setText("");
        txtDataNascimento.setText("");
        cbSexo.setSelectedIndex(0);
        cbTipoDiabetes.setSelectedIndex(0);
        txtDataDiagnostico.setText("");
        txtNivelAcucarSangue.setText("");
        txtPeso.setText("");
        txtAltura.setText("");
        txtPressaoArterial.setText("");
        txtHistoricoMedico.setText("");
        txtMedicamentos.setText("");
        txtAlergias.setText("");
        txtSenha.setText("");
    }

    // Método para listar os usuários do banco de dados na tabela
    private void listarUsuarios() {
        try {
            // Cria uma instância da classe UsuarioDAO para interagir com o banco de dados
            UsuarioDAO dao = new UsuarioDAO();
            List<Usuario> usuarios = dao.listarUsuarios(); // Obtém a lista de usuários do banco de dados
            dao.fecharConexao(); // Fecha a conexão com o banco de dados

            // Limpa a tabela
            modeloTabela.setRowCount(0);

            // Define as colunas da tabela
            modeloTabela.setColumnIdentifiers(new String[]{
                    "ID", "Nome", "CPF", "Email", "Data de Nascimento", "Sexo",
                    "Tipo de Diabetes", "Data de Diagnóstico", "Nível de Açúcar",
                    "Peso", "Altura", "Pressão Arterial", "Histórico Médico",
                    "Medicamentos", "Alergias"
            });

            // Adiciona os usuários à tabela
            for (Usuario usuario : usuarios) {
                modeloTabela.addRow(new Object[]{
                        usuario.getId(), usuario.getNome(), usuario.getCpf(), usuario.getEmail(),
                        usuario.getDataNascimento(), usuario.getSexo(), usuario.getTipoDiabetes(),
                        usuario.getDataDiagnostico(), usuario.getNivelAcucarSangue(),
                        usuario.getPeso(), usuario.getAltura(), usuario.getPressaoArterial(),
                        usuario.getHistoricoMedico(), usuario.getMedicamentos(), usuario.getAlergias()
                });
            }

            // Torna a tabela visível
            painelTabela.setVisible(true);

        } catch (SQLException ex) {
            // Exibe uma mensagem de erro se houver algum problema ao interagir com o banco de dados
            JOptionPane.showMessageDialog(this, "Erro ao listar usuários: " + ex.getMessage());
        }
    }
    private void excluirUsuario() {
        UsuarioDAO dao = new UsuarioDAO();
        try {
            int id = Integer.parseInt(txtIdExcluir.getText());
            dao.excluir(id); // Exclui o usuário do banco de dados
            dao.fecharConexao(); // Fecha a conexão

            // Exibe uma mensagem de sucesso
            JOptionPane.showMessageDialog(this, "Usuário excluído com sucesso!");

            // Atualiza a tabela com a lista de usuários atualizada
            listarUsuarios(); // Chama listarUsuarios() para atualizar a tabela

            // Remove a linha da tabela correspondente ao ID excluído
            // (Agora essa ação será aplicada à tabela atualizada)
            for (int i = 0; i < modeloTabela.getRowCount(); i++) {
                if (modeloTabela.getValueAt(i, 0).equals(id)) {
                    modeloTabela.removeRow(i);
                    break; // Encontrou o ID, para de procurar
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Erro: Insira um ID válido.");
        }
    }
    // Método principal que cria uma instância da classe UsuarioGUI
    public static void main(String[] args) {

        new UsuarioGUI();
    }
}